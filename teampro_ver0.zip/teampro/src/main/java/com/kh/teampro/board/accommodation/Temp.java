package com.kh.teampro.board.accommodation;

public class Temp {

}
