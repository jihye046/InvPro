package com.kh.teampro.point;

public class Temp {

}
